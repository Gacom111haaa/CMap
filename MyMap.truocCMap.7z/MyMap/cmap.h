#ifndef CMAP_H
#define CMAP_H

#include <QObject>
#include <QtGui>

class CMap : public QObject
{
    Q_OBJECT
public:
    explicit CMap(QObject *parent = 0);
    //CMap();
    virtual ~CMap();
    QPixmap* mMapImage;

    double GetScaleRatio();
    void Repaint();
    void SetCenterPos(double lat, double lon);
    void SetScaleRatio(double scale);
    void invalidate();

private:
    /**
    * WGS coordinates of center point of the map
    */
    double mCenterLat;
    /**
    * WGS coordinates of center point of the map
    */
    double mCenterLon;
    /**
    * Height of mMapImage in pixels
    */
    int mMapHeight;
    /**
    * Width of mMapImage in pixels
    */
    int mMapWidth;
    /**
    * Scale factor from km to pixels, if mScale = 5, it means 1 km is equal to 5
    * pixels in mMapImage
    */
    double mScale;

    QPoint m_offset;
    QRect m_tilesRect;
    QPixmap m_emptyTile;
    QHash<QPoint, QPixmap> m_tilePixmaps;
    //QNetworkAccessManager m_manager;
    QUrl m_url;

    QRect tileRect(const QPoint &tp);

signals:

public slots:
};

#endif // CMAP_H
