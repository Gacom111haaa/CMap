#include "cmap.h"

CMap::CMap(QObject *parent) : QObject(parent)
{

#include "CMap.h"


CMap::CMap(){

}



CMap::~CMap(){

}





/**
 * Tr? v?  mScale
 */
double CMap::GetScaleRatio(){

    return 0;
}


/**
 * V? l?i mMapImage, hàm này du?c g?i m?i khi có s? thay d?i các tham s? c?a b?n d?
 */
void CMap::Repaint(){

}


/**
 * Ð?t giá tr? cho mCenterLat, mCenterLon
 */
void CMap::SetCenterPos(double lat, double lon){

}


/**
 * Ð?t giá tr? cho mScale
 */
void CMap::SetScaleRatio(double scale){

}
