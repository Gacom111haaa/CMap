#ifndef DOWNLOADDER_H
#define DOWNLOADDER_H

#include <QObject>

class Downloadder
{
public:
    Downloadder();
};

#endif // DOWNLOADDER_H